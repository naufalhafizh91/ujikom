<?php
session_start();
// mendapatkan id dari url
$id_produk = $_GET['id'];

// jika sudah ada produk di keranjang, maka produk itu jumlahnya  di+1
if(isset($_SESSION['keranjang'][$id_produk]))
{
    $_SESSION['keranjang'][$id_produk]+=1;
}
else
{
    $_SESSION['keranjang'][$id_produk]=1;
}

echo "<script>alert('produk telah masuk ke dalam ranjang')</script>";
echo "<script>location='keranjang.php';</script>";
?>