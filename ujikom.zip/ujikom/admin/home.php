<h2>selamat datang kamu</h2>
<pre><?php print_r($_SESSION)?></pre>