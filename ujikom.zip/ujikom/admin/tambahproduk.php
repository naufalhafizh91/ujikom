<?php 
if (isset($_POST['save']))
{
    // $nama = $_FILES['nama'];
    $nama = $_POST['nama'];
    // echo var_dump($nama);

    $photo = $_FILES['foto_produk'];
    // echo var_dump($photo);

    $harga = $_POST['harga'];
    // echo var_dump($harga);
    
    $berat = $_POST['berat'];
    // echo var_dump($berat);
    
    $deskripsi = $_POST['deskripsi'];
    // echo var_dump($deskripsi);

    $stok = $_POST['stok'];
    // echo var_dump($stok);

    $nama_photo = explode('.', $photo['name']) ;


    $uniqname = uniqid();
    $nama_photo = $nama_photo[0]."$uniqname".".$nama_photo[1]";
    
    $lokasi =$_FILES['foto']['tmp_name'];

    $success = move_uploaded_file($_FILES['foto_produk']['tmp_name'], '../foto_produk/'.$nama_photo);
    // echo 'berhasil' . var_dump($success);

    $koneksi->query("INSERT INTO produk 
    (nama_produk,harga_produk,berat_produk,foto_produk,deskripsi_produk,stok_produk)
    VALUES('$_POST[nama]','$_POST[harga]','$_POST[berat]','$nama_photo','$_POST[deskripsi]','$_POST[stok]')" );


    echo "<div class='alert alert-info'>Data tersimpan</div>";
    echo "<meta http-equiv='refresh' content='1;url=index.php?halaman=produk'>";

}
?>

<h2>tambah produk</h2>

<form method="post" enctype="multipart/form-data">
<div class="form-group">
    <label>nama</label>
    <input type="text" class="form-control" name="nama">
</div>
<div class="form-group">
    <label>Harga (Rp)</label>
    <input type="number" class="form-control" name="harga">
</div>
<div class="form-group">
    <label>Berat (Gr)</label>
    <input type="number" class="form-group" name="berat">
</div>
<div class="form-group">
    <label>Deskripsi</label>
    <textarea class="form-control" name="deskripsi" rows="10"></textarea>
</div>
<div class="form-group">
    <label>Foto</label>
    <input type="file" class="form-control" name="foto_produk">
</div>
<div class="form-group">
    <label>input stok produk</label>
    <input type="number" min="1" class="form-control" name="stok">

</div>
<button class="btn btn-primary" name="save">Simpan</button>
<INPUT TYPE="button" VALUE="Kembali" onClick="history.go(-1);" class="btn btn-succes">

</form>
