<?php 
session_start();
include 'koneksi.php';

if(!isset($_SESSION["pelanggan"]) OR empty($_SESSION["pelanggan"]))
{
    echo "<script>alert('login dulu bray');</script>";
    echo "<script>location='login.php';</script>";
    exit();
}
$idpem = $_GET["id"];
$ambil = $koneksi->query("SELECT * FROM pembelian WHERE id_pembelian='$idpem'");
$detpem = $ambil->fetch_assoc();

$id_pelanggan_beli = $detpem["id_pelanggan"];
$id_pelanggan_login = $_SESSION["pelanggan"]["id_pelanggan"];

if($id_pelanggan_beli !== $id_pelanggan_login)
{
    echo "<script>alert('jangan kepo yaa');</script>";
    echo "<script>location='riwayat.php';</script>";
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pembayaran</title>
    <link rel="stylesheet" href="admin/assets/css/bootstrap.css">
</head>
<body>
    <?php include 'menu.php'; ?>

    <div class="container">
        <h2>Konfirmasi Pembayaran</h2>
        <p>Kirim Bukti Pembayaran Anda Disini</p>
        <div class="alert alert-info">Total Tagihan Anda <br>
        <strong> Rp. <?php echo number_format($detpem["total_pembelian"]); ?></strong></div>

    <form method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label>Nama Penyetoran</label>
            <input type="text" class="form-control" name="nama">
        </div>
        <div class="form-group">
            <label>Bank</label>
            <input type="text" class="form-control" name="bank">
        </div>
        <div class="form-group">
            <label>Jumlah</label>
            <input type="number" class="form-control" name="jumlah" min="1">
        </div>
        <div class="form-group">
            <label>Foto Bukti</label>
            <input type="file" class="form-control" name="bukti">
            <p class="text-danger">foto harus format JPG maksimal 2mb</p>
        </div>
        <button class="btn btn-primary" name="kirim">Kirim</button>
    </form>
    </div>

    <?php 
    if (isset($_POST["kirim"]))
    {
    $nama = $_POST['nama'];
    $bank = $_POST['bank'];
    $jumlah = $_POST['jumlah'];
    $foto = $_FILES['bukti'];
    
    
// Check if file was uploaded without errors
if(isset($_FILES["bukti"]) && $_FILES["bukti"]["error"] == 0){
    $filename = explode('.', $foto['name']) ;
    $uniqname = uniqid();
    $filename = $filename[0]."$uniqname".".$filename[1]";
    $tempname = $_FILES["bukti"]["tmp_name"];
    $folder = "bukti_pembayaran/".$filename;

    // Move uploaded file to target destination
    if(move_uploaded_file($tempname, $folder)){
        echo "File uploaded successfully.";
    } else{
        echo "Error uploading file.";
    }
} else{
    echo "Error: " . $_FILES["file"]["error"];
}



    $koneksi->query("INSERT INTO pembayaran 
    (id_pembelian,nama,bank,jumlah,bukti)
    VALUES('$idpem','$nama','$bank','$jumlah','$filename')" );

    $koneksi->query("UPDATE pembelian SET status_pembelian='sudah kirim pembayaran' 
    WHERE id_pembelian='$idpem'");


    echo "<script>alert('allhamdulillah data tersimpan');</script>";
    echo "<script>location='riwayat.php';</script>";


        

    }
    ?>
</body>
</html>